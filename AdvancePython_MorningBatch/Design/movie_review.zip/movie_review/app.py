from flask import Flask, render_template, redirect, url_for
from flask.globals import request
import mysql.connector

app = Flask(__name__)


def database_CONNECTIVITY():
    db = mysql.connector.connect(host="sql545.main-hosting.eu",
                                 port=3306,
                                 user='u681323537_grras_SQL',
                                 password='5;YbQ1!JtPpY',
                                 db="u681323537_learnsql")

    myc = db.cursor()
    print("print myc: ", myc)
    return(db, myc)

@app.route('/')
def index():
    return render_template ('index.htm')


@app.route('/password.htm')
def password():
    return render_template('password.htm')


@app.route('/report.htm')
def report():
    lower = False
    upper = False
    num = False

    password = request.args.get('password')

    lower = any(c.islower() for c in password)
    upper = any(c.isupper() for c in password)
    num = any(c.isdigit() for c in password)

    report = lower and upper and num

    return render_template('report.htm', report=report, lower=lower, upper=upper, num=num)

@app.route('/signup')
def signup():
    return render_template('signup.htm')

@app.route('/aftersignup', methods=['GET', 'POST'])
def aftersignup():
    if request.method == 'GET':
        return redirect(url_for('signup'))
    else:
        susername = request.form.get("susername")
        semail = request.form.get("semail")
        spassword = request.form.get("spassword")
        db, myc = database_CONNECTIVITY()
        
        myc.execute(f"select email from users where email='{semail}'")
        data=myc.fetchall()
        
        if data:
            msg='Email Already exist'
            return render_template('login.htm', msg=msg)
        else:
            cmd= f"insert into users values ('{susername}','{semail}','{spassword}')"
            myc.execute(cmd)
            db.commit()
            msg="Successfully Registered"
            return render_template('login.htm', msg=msg)
        #return f"{susername}, {semail}, {spassword}"
        
        
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

if __name__=='__main__':
    app.run()
