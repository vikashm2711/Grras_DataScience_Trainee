from flask import Flask

app =Flask(__name__)


@app.route('/')
def index():
    return "<h1> Hello World !</h1>"

@app.route('/info')
def info():
    return "<h1> hello world is great to start programm </h1>"   

@app.route('/info/<name>')
def info2(name):
    return f"<h1> {name[2]} programm </h1>"

@app.route('/latin/<name>')
def check(name):
    if name[-1]=='y':
        name=name[:-1]+'iful'
    else:
        name=name+'y'
    return f"latin name: {name}"

if __name__=='__main__':
    app.run(debug=True)
