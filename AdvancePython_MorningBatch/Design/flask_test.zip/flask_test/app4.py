from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def username():
    return render_template('username.htm')
    

@app.route('/report.htm')
def report():
    lower=False
    upper=False
    num=False

    username=request.args.get('username')
    
    lower = any(c.islower() for c in username)
    upper = any(c.isupper() for c in username)
    num = any(c.isdigit() for c in username)
    
    report = lower and upper and num
    
    return render_template('report.htm', report=report, lower=lower, upper=upper,num=num)

if __name__ == "__main__":
    app.run(debug=True)
