from flask import Flask, render_template

app= Flask(__name__)


letter=['k','a']

@app.route('/')
def index():
    name_='vikash'
    return render_template('basic.html', name_=name_, letter=letter)

if __name__ == '__main__':
    app.run(debug=True)