	/*  Wizard */
	jQuery(function ($) {
		"use strict";
		// Chose here which method to send the email, available:
		// Phpmaimer text/html > phpmailer/review_phpmailer.php
		// Phpmaimer text/html SMPT > phpmailer/review_phpmailer_smtp.php
		// PHPmailer with html template > phpmailer/review_phpmailer_template.php
		// PHPmailer with html template SMTP> phpmailer/review_phpmailer_template_smtp.php
		$('form#wrapped').attr('action', 'phpmailer/review_phpmailer_template.php');
	});